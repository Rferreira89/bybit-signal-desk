# Bybit Signal Desk (USDC preferred)

Sistema profissional de **sinais Long + Short** de alta qualidade para Bybit.

- Prioriza pares **USDC**
- Analisa todos os pares disponíveis (USDC + USDT de alta liquidez)
- Filtros rigorosos de liquidez, volume e estrutura
- Envia apenas os melhores setups para o Telegram
- Sem execução automática — tu decides

## ⚠️ Aviso de Risco

Capital pequeno tem risco **muito elevado** de perda total.  
Este sistema não garante lucros.

## Funcionalidades

- Scan 24/7
- Preferência clara por pares USDC
- Filtros duros de liquidez e volume
- Análise de estrutura (EMA, RSI, momentum, volume)
- Só envia sinais com qualidade mínima e R:R ≥ 1.8
- Cooldown por símbolo
- Logs completos

## Como colocar no GitHub + Railway (recomendado)

1. Cria um repositório **Private** no GitHub chamado `bybit-signal-desk`
2. Faz upload de todos os ficheiros desta pasta
3. Vai a [railway.app](https://railway.app) → New Project → Deploy from GitHub repo
4. Adiciona as variáveis de ambiente:
   ```
   TELEGRAM_BOT_TOKEN=teu_token
   TELEGRAM_CHAT_ID=teu_chat_id
   ```
5. Start Command: `python src/main.py`
6. Deploy

## Variáveis de ambiente

```
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
BYBIT_BASE_URL=https://api.bybit.com
SCAN_INTERVAL_MINUTES=15
MIN_TURNOVER_USDT=300000
```

## Notas Bybit EU

Bybit EU = Spot + Margin (sem perpetual futures).  
Sinais de Short são para margin quando disponível.

## Estrutura

```
bybit-signal-desk/
├── src/
│   ├── main.py
│   ├── config.py
│   ├── bybit_client.py
│   ├── filters.py
│   ├── analysis.py
│   └── telegram_sender.py
├── logs/
├── requirements.txt
├── .env.example
└── README.md
```

## Disclaimer

Ferramenta de análise apenas. Não é aconselhamento financeiro.  
Tu és o único responsável pelas tuas decisões.
